import React from 'react';

import {Title} from './styles';

export default function Main(){
  return(
    <Title>
      Main
    </Title>
  )
}