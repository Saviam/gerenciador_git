import React from 'react';

export default function Repositorio(){
  return(
    <h1>Repositorio</h1>
  )
}